#include <iostream>
using namespace std;


//Constant declaration:
const int ARRAY_SIZE = 2;


//Prototype decleration:
void get_matrix_input(int[][ARRAY_SIZE], int);
bool is_plus();
int* calculate_matrix(int[][ARRAY_SIZE], int array_size, bool is_even);
void report_matrix_result(int[], int, bool);
char get_operator_char(bool);



int main(){

    int matrix[ARRAY_SIZE][ARRAY_SIZE];
    get_matrix_input(matrix, ARRAY_SIZE);
    bool selected_operation = is_plus();
    int *matrix_result = calculate_matrix(matrix, ARRAY_SIZE, selected_operation);
    report_matrix_result(matrix_result, ARRAY_SIZE, selected_operation);
    return 0;

}


//Ask users to input the value for each element of the 2D array
void get_matrix_input(int matrix[][ARRAY_SIZE], int array_size){

    for (int i = 0; i < array_size; i++){

        for (int j = 0; j < array_size; j++){

            cout << "Please enter the value for matrix [" << i << "][" << j <<"]: ";
            cin >> matrix[i][j];
            cout << endl;

        }
    }
}


//Returns a pointer to an array which stores the computed results
int* calculate_matrix(int matrix[][ARRAY_SIZE], int array_size, bool is_plus){

    static int computed_matrix[ARRAY_SIZE];

    if (is_plus){

        for (int i = 0; i < array_size; i++){

            computed_matrix[i] = matrix[0][i] + matrix[1][i];

        }
    }

    else {

        for (int i = 0; i < array_size; i++){

            computed_matrix[i] = matrix[0][i] - matrix[1][i];

        }

    }

    return computed_matrix;

}


//Prompts the user to choose an operator and returns true if plus was selected
bool is_plus(){

    int computation_input = 0;

    do {

        cout << "PLease choose an operator to compute the two matrices: \n";
        cout << "Press '1' for +" << endl;
        cout << "Press '2' for -" << endl;
        cin >> computation_input;

    } while (computation_input != 1 && computation_input != 2);

    if (computation_input == 1){

        return true;

    }

    return false;

}


//Announces the results of the matrix
void report_matrix_result(int matrix_result[], int array_size, bool selected_operator){

    cout << "The results are: " << endl;

    for (int i = 0; i < array_size; i++){

        cout << "matrix[0][" << i << "] " << get_operator_char(selected_operator) << " matrix[1][" << i << "] = ";
        cout << matrix_result[i] << " \n";

    }

    cout << endl;
}


//In-takes the bool and returns the character data type of the operator
char get_operator_char(bool selected_operator){

    if (selected_operator){

        return '+';

    }

    return '-';

}







